// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,

  firebaseConfig: {
    apiKey: "AIzaSyDMRx8iIWHVioroRieXWzwP6-0A76bVxc0",
    authDomain: "login-f9fec.firebaseapp.com",
    databaseURL: "https://login-f9fec.firebaseio.com",
    projectId: "login-f9fec",
    storageBucket: "login-f9fec.appspot.com",
    messagingSenderId: "194021762538",
    appId: "1:194021762538:web:3972cfa13b1c74b51dfe93",
    measurementId: "G-GYQYPTGPH3"
  }
};



/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
