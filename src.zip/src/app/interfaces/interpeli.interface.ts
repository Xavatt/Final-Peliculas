export interface Ipelis
{
    Title: string;
    Genre?: string;
    ImdbRating: string;
    Year: string;
    Director: string;
    Actors: string;
    Poster: string;
    Type: string;
}