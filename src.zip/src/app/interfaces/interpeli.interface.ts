export interface Ipelis
{
    Title: string;
    Genero: string;
    Raiting: string;
    Año: string;
    Director: string;
    Actores: string;
    Poster: string;
    Type: string;
}